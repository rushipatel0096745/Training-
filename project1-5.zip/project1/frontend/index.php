<?php

    ini_set('display_errors', 'On');
    error_reporting(E_ALL);

    require '../database/db_connect.php';

    $sql = "
            SELECT P.p_id AS p_id, P.product_name AS product_name, P.price AS price, P.compare_price AS compare_price, P.image AS image, P.description AS description, GROUP_CONCAT(C.category_name) AS 'categories'
            FROM product P 
            LEFT JOIN product_category PC ON P.p_id = PC.p_id 
            LEFT JOIN category C ON C.c_id = PC.c_id
            GROUP BY P.p_id
        ";

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $all_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>


<!doctype html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body>

    <!-- navbar -->
    <?php include '../frontend/components/navbar.php' ?>

    <!-- displaying all products -->
    <div class="conatainer mt-4">
        <div class="row row-cols-1 row-cols-md-3 g-3">
            <?php foreach ($all_products as $p) { ?>
                <div class="col w-25 p-4">
                    <div class="card h-100" style="width: 18rem;">
                        <img src="<?php echo $p["image"] ?>" class="card-img-top" alt="..." width="200px" height="200px">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $p["product_name"]; ?></h5>
                            <p class="card-text"><strong>Categories:</strong> <?php echo $p["categories"]; ?></p>
                            <p class="card-text"><strong>Description:</strong> <?php echo $p["description"]; ?></p>
                            <p class="card-text"><strong>Price: </strong><?php echo $p["price"]; ?>&#8377 <span class="text-decoration-line-through" style="margin-left: 10px;"><?php echo $p["compare_price"]; ?>&#8377 </span></p>
                            <div class="row">
                                <div class="col col-sm-6">
                                    <a href="./update_product.php/?p_id=<?php echo $p["p_id"] ?>" class="btn btn-primary" target="_blank">Add to cart</a>
                                </div>
                                <div class="col col-sm-6">
                                    <a href="./delete_product.php/?p_id=<?php echo $p["p_id"] ?>" class="btn btn-success">Buy</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>