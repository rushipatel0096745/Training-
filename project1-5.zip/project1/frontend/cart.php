<?php

session_start();
ini_set('display_errors', 'On');
error_reporting(E_ALL);

require '../database/db_connect.php';

$_SESSION["cart"] = [
    // ["p_id" => 1, "quantity" => 4, "price" => 300] 
    36 => ["quantity" => 4, "price" => 300],
    42 => ["quantity" => 3, "price" => 300]
];

$cart = $_SESSION["cart"];

// echo json_encode($cart);

// echo "p_id: " . array_keys($cart)[0];

$product_ids = array_keys($cart);
// fetch product with product id
$products = [];


// foreach($product_ids as $p_id){
//     $product_fetch_sql = SELECT * FROM product WHERE 
// }

$placeholders = implode(',', array_fill(0, count($product_ids), '?'));

try {
    $product_fetch_sql = "SELECT * FROM product WHERE p_id IN ($placeholders)";
    echo "from the inside";
    $product_fetch_stmt = $conn->prepare($product_fetch_sql);
    $product_fetch_stmt->execute($product_ids);
    $products = $product_fetch_stmt->fetchAll(PDO::FETCH_ASSOC);

    var_dump($products);
} catch (PDOException $e) {
    echo "error: " . $e->getMessage();
}


foreach ($products as $p) {
    echo "p_id " . "=>" . $p["p_id"] . "<br>";
    echo "product_name"  . "=>" . $p["product_name"] . "<br>";
    echo "image" . "=>" . $p["image"] . "<br>";
}

?>


<!doctype html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body>
    <div class="container-fluid p-o m-o">
        <div class="container text-center">
            <div class="row align-items-center">
                <div class="col border border-danger-subtle">
                    <div class="cart-header d-flex">
                        <h2>Cart</h2>
                    </div>
                    <div class="cart-content">
                        <div class="card mb-3" style="max-width: 540px;">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="..." class="img-fluid rounded-start" alt="...">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">Card title</h5>
                                        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col border border-danger-subtle">
                    One of three columns
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>