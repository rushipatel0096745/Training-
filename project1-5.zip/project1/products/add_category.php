<?php 
    session_start();
    if(!isset($_SESSION["admin1"])){
        header("Location: ../login.php");
        exit();
    }
?>

<?php 
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    require '../database/db_connect.php';
    // fetch all the categories
    try {
        $cat_sql = "SELECT * FROM category order by c_id";
        $cat_stmt = $conn->prepare($cat_sql);
        $cat_stmt->execute();
        $categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "error: " . $e->getMessage();
    }

    
    // echo "last cat id " . " " . "$last_cat_id";
    $errMsg = "";
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["category"])){
            $errMsg = "enter the category name";
        } else {
            $category_name = $_POST["category"];
        }
        
        if($errMsg == ""){
            
            try {
                // inserting category
                foreach($categories as $c){
                    $last_cat_id = $c["c_id"];
                }
                $insert_sql = "INSERT INTO category (c_id, category_name) VALUES (?,?)";
                $insert_stmt = $conn->prepare($insert_sql);
                $insert_stmt->execute([$last_cat_id+1, $category_name]);
                
            } catch (PDOException $e) {
                echo "error: " . $e->getMessage();
            }

            header("Location: http://localhost/rushikesh/project1/products/add_category.php");
            exit();
        }

    }
?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>    
    <div class="container-fluid p-0 m-0">

        <?php include '../components/navbar.php' ?>

        <div class="container mt-5 mx-auto ">

            <!-- add category modal  -->
            <div class="modal modal-sm fade" id="addCategory" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <!-- <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Category</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div> -->
                    <div class="modal-body">
                        <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" class="row g-3" onsubmit="return submitHandler(event)">
                            
                            <div class="card">
                                <div class="card-header">
                                    Add Category
                                </div>
                                <div class="card-body">
                                    <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>" onsubmit="">
                                        <label for="category">Category name</label>
                                        <input type="text" name="category" class="form-control category">
                                        <div class="text-danger"><?php echo $errMsg; ?></div>
                                        <input type="submit" class="btn btn-primary mt-3"></input>
                                    </form>
                                </div>
                            </div>
                                
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-between">
                <div class="col-md-6">
                    <h4>Categories</h4>
                </div>
                <div class="col-md-6">
                    <a href="" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategory">Add Category</a>
                </div>
            </div>
            <div class="row">
                <table class="table">
                    <thead>
                        <th scope="col">category_id</th>
                        <th scope="col">Category name</th>
                        <th scope="col">Action</th>
                    </thead>
                    <tbody>
                        <?php foreach($categories as $c){ ?>
                            <tr>
                                <td><?php echo $c["c_id"] ?></td>
                                <td><?php echo $c["category_name"] ?></td>
                                <td>
                                    <div class="row" style="width: 180px;">
                                        <div class="col-sm-6">
                                            <!-- <button type="button" class="btn btn-outline-danger btn-sm" onclick="window.location = 'http://localhost/rushikesh/project1/products/delete_category.php'">Delete</button> -->
                                            <a href="http://localhost/rushikesh/project1/products/delete_category.php/?c_id=<?php echo $c["c_id"] ?>" class="btn btn-outline-danger btn-sm">Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>  
    </div>
    <script>
        function submitHandler(event){
            const category = document.querySelector(".category");
            if(category.value == ""){
                category.nextElementSibling.textContent = "Enter the category";
                return false;
            } else {
                return true;
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>