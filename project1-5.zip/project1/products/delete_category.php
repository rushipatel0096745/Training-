<?php 
    session_start();
    if(!isset($_SESSION["admin1"])){
        header("Location: ../login.php");
        exit();
    }
?>

<?php
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    require '../database/db_connect.php';
    $cat_id = (int)$_GET["c_id"];    

    $delete_sql = "DELETE FROM category WHERE c_id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->execute([$cat_id]);

    header("Location: http://localhost/rushikesh/project1/products/add_category.php");
    exit(); 


?>