<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require './vendor/autoload.php';


function initializeMailer() {
    $mail = new PHPMailer(true); // Passing 'true' enables exceptions

    try {
        // Server settings
        $mail->SMTPDebug = 0;                                       
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com;';                    
        $mail->SMTPAuth   = true;                             
        $mail->Username   = 'rp0096745@gmail.com';                 
        $mail->Password   = 'gjmndkiyygxmlvwv';                        
        $mail->SMTPSecure = 'tls';                              
        $mail->Port       = 587;  

        // Sender settings
        $mail->setFrom('rp0096745@gmail.com', 'rushi patel');    
        
        return $mail;

    } catch (Exception $e) {
        error_log("Mailer Initialization Error: " . $e->getMessage());
        return null;
    }
}


                    // $tree = [];
                    // $root_parent = -1;
                    // $root_parent_name = "";

                    // function makeTree($query,&$tree,&$root_parent,&$root_parent_name){
                    //     while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    //         if($row['parent_id'] == 0){
                    //             $root_parent = $row['id'];
                    //             $root_parent_name = $row['name'];
                    //         }else{
                    //             if(!isset($tree[$row['parent_id']])){
                    //                 $tree[$row['parent_id']] = [];
                    //             }          
                    //             $tree[$row['parent_id']][] = array($row['name'],$row['id']);
                    //         }    
                    //     }   
                    // }

                    // function buildList($tree,$parent){
                    //     $list = "<ul>";

                    //     foreach($tree[$parent] as $each_child){
                    //         $list .= "<li>" . $each_child[0];
                    //         if(isset($tree[$each_child[1]])){
                    //             $list .= buildList($tree,$each_child[1]);
                    //         }
                    //         $list .= "</li>";
                    //     }

                    //     $list .= "</ul>";

                    //     return $list;
                    // }


                    // makeTree($nav_sql,$tree,$root_parent,$root_parent_name);


                    // echo "<ul>";
                    // echo "<li>$root_parent_name";
                    // echo buildList($tree,$root_parent);
                    // echo "</li>";
                    // echo "</ul>";

?>