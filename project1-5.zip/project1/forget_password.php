<?php 
    session_start();
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    require './email_config/email_config.php';
    require './database/db_connect.php';

    $errMsg = "";
    $email = "";
    if($_SERVER["REQUEST_METHOD"] == "POST"){

        if(empty($_POST["email"])){
            $errMsg = "enter the email";
        } else {
            $email = $_POST["email"];
        }

        echo "$email";

        // checking email is in database
        $checkEmailSql = "SELECT email, admin_id FROM admin WHERE email = ? AND admin_id != 1";
        $stmt = $conn->prepare($checkEmailSql);
        $stmt->execute([$email]);
        $checkEmail = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if($checkEmail){
            foreach($checkEmail as $c){
                $reset_email = $c["email"];
                $reset_admin_id = $c["admin_id"];
            }

            
            // generate the 4 digit otp
            $otp_value = random_int(0, 9999);
            $otp = str_pad($otp_value, 4, "0", STR_PAD_LEFT);
            
            $expiry_time = date('Y-m-d H:i:s', strtotime('+15 minutes')); 
            
            // store otp in database
            $insert_sql = "INSERT INTO password_reset (admin_id, email, otp, expires_at) VALUES (?,?,?,?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->execute([$reset_admin_id, $reset_email, $otp, $expiry_time]);
            $last_id = $conn->lastInsertId();
            
            // store email and admin_id in session
            $_SESSION["reset_email"] = $reset_email;
            $_SESSION["reset_admin_id"] = $reset_admin_id;
            $_SESSION["reset_id"] = $last_id;

            // send otp in email
            $mail = initializeMailer();

            if($mail){
                try{
                    $mail->setFrom('rp0096745@gmail.com', 'rushi patel');           
                    $mail->addAddress($email);
                    $mail->Subject = 'OTP for password';
                    $mail->Body    = 'otp for changing password'. " " . $otp;
                    $mail->AltBody = 'otp for changing password'. " " . $otp;
                    $mail->send();
                    header("Location: verify_otp.php");
                    exit();
                } catch(Exception $e){
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                echo "email config error";
            }

        } else {
            $errMsg = "Email not found";
        }
    }

?>

<!doctype html>
<html lang="en" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Password Reset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="container d-flex align-items-center justify-content-center vh-100"> 
            <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
                <div class="row mb-3 text-center">
                    <h1>Forget Password</h1>
                </div>
                <div class="row mb-3">
                    <label for="password" class="col-sm-4 col-form-label">Enter the email</label>
                    <div class="col-sm-8">
                    <input type="text" name="email" class="form-control">
                    </div>
                </div>
             
                <div class="row mb-3 justify-content-center text-center" style="margin-top: 30px;">
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
                <div class="row mb-3 justify-content-center text-center" style="margin-top: 30px;">
                    <div class="col-auto">
                       <p><?php echo "$errMsg"; ?></p>
                    </div>
                </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>