<?php 
    session_start();
    include './database/db_connect.php';

    $nav_sql = $conn->query("select * from navigation where parent_id = 0 order by id");
    // $nav_stmt = $conn->prepare($nav_sql);
    // $nav_stmt->execute();
    // $nav = $nav_stmt->fetchAll(PDO::FETCH_ASSOC);

    // echo json_encode($nav);

    // // echo var_dump($nav) . "<br/>" . "<br/>";

    // echo $nav[0]["name"] . "<br>";

    // echo "<ul>";
    // foreach($nav as $n){
    //     // echo $n . "=>" . $nk . "<br>";
    //         foreach($n as $k => $v){
    //             echo $k . "=>" . $v . "<br>";
    //         }
    // }
    // echo "</ul>";




    //     function echo_menu($menu_array) {
    //         //go through each top level menu item
    //         foreach($menu_array as $menu) {
    //             echo "<li>{$menu['name']}</a>";
    //             //see if this menu has children
    //             if(array_key_exists('parent_id', $menu)) {
    //                 echo '<ul>';
    //                 //echo the child menu
    //                 echo_menu($menu['parent_id']);
    //                 echo '</ul>';
    //             }
    //             echo '</li>';
    //         }
    //     }

    //     echo '<ul>';
    //     echo_menu($nav);
    //     echo '</ul>';


    $sql = "WITH RECURSIVE menu_hierarchy AS (
        -- Anchor member: Select top-level menu items (parent_id IS NULL)
        SELECT
            id,
            parent_id,
            name,
            url,
            1 AS level -- Start at level 1
        FROM
            navigation
        WHERE
            parent_id = 0
        
        UNION ALL
        
        -- Recursive member: Join the menu table with the CTE result
        SELECT
            m.id,
            m.parent_id,
            m.name,
            m.url,
            mh.level + 1 AS level -- Increment level for sub-items
        FROM
            navigation AS m
        INNER JOIN
            menu_hierarchy AS mh ON m.parent_id = mh.id
    )
    -- Order the final result for presentation
    SELECT
        *
    FROM
        menu_hierarchy
    ORDER BY
        parent_id ASC, -- Ensures top-level items appear first
        id;
    ";


    $stmt = $conn->prepare($sql);
    $menu = $stmt->fetchAll(PDO::FETCH_ASSOC);




                    $tree = [];
                    $root_parent = -1;
                    $root_parent_name = "";

                    function makeTree($query,&$tree,&$root_parent,&$root_parent_name){
                        while($row = $query->fetch(PDO::FETCH_ASSOC)){
                            if($row['parent_id'] == 0){
                                $root_parent = $row['id'];
                                $root_parent_name = $row['name'];
                            }else{
                                if(!isset($tree[$row['parent_id']])){
                                    $tree[$row['parent_id']] = [];
                                }          
                                $tree[$row['parent_id']][] = array($row['name'],$row['id']);
                            }    
                        }   
                    }

                    function buildList($tree,$parent){
                        $list = "<ul>";

                        foreach($tree[$parent] as $each_child){
                            $list .= "<li>" . $each_child[0];
                            if(isset($tree[$each_child[1]])){
                                $list .= buildList($tree,$each_child[1]);
                            }
                            $list .= "</li>";
                        }

                        $list .= "</ul>";

                        return $list;
                    }


                    makeTree($nav_sql,$tree,$root_parent,$root_parent_name);


                    echo "<ul>";
                    echo "<li>$root_parent_name";
                    echo buildList($tree,$root_parent);
                    echo "</li>";
                    echo "</ul>";

                    
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Navigation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                <?php echo "<ul class='navbar-nav'>" ?>
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="#">Features</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="#">Pricing</a>
                    </li>
                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Dropdown link
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Action</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                    </li>
                <!-- </ul> -->
                <?php echo "<ul>" ?>
                </div>
            </div>
        </nav>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>