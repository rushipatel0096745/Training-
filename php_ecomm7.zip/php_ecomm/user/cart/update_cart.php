<?php
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    session_start();

    require_once __DIR__ . "../../../constants.php";
    require __DIR__ . '../../../database/db_connect.php';


    $product_id = intval($_POST["product_id"]);
    $action = $_POST["action"];

    if($action == "increase"){
        $_SESSION["cart"][$product_id]++;
    }
    if($action == "decrease"){
        $_SESSION["cart"][$product_id]--;
        if($_SESSION["cart"][$product_id] == 0){
            unset($_SESSION["cart"][$product_id]);
        }
    }

    // fetching all cart items
    $cart_items = $_SESSION["cart"] ?? [];

    $cart_total = 0;
    if (empty($cart_items)) {
        $products = [];
    } else {
        $all_product_ids = array_keys($cart_items);
        $placeholder = array_fill(0, count($all_product_ids), "?");
        $placeholder = implode(",", $placeholder);

        $product_sql = "SELECT * FROM product WHERE p_id IN ($placeholder)";
        $product_stmt = $conn->prepare($product_sql);
        $product_stmt->execute($all_product_ids);
        $products = $product_stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($products as &$product) {
            $product["quantity"] = $cart_items[$product["p_id"]];
            $product["subtotal"] = $product["quantity"] * $product["price"];
            if($product["p_id"] == $product_id){
                $product_total = $product["subtotal"];
            }
            $cart_total += $product["subtotal"];
        }
    }


    // checking user has existed cart in cart table
    $user_cart_sql = "SELECT cart_id FROM cart WHERE user_id = ?";
    $user_cart_stmt = $conn->prepare($user_cart_sql);
    $user_cart_stmt->execute([$_SESSION["login_user_id"]]);
    $cart_id = $user_cart_stmt->fetchColumn();
    $_SESSION["cart_id"] = $cart_id ?? 0;
    echo "cart_id" . $cart_id;


    // update the cart and cart_item table
    if(!$_SESSION["cart"][$product_id]){
        // remove product from the cart_item
        $remove_sql = "DELETE FROM cart_items WHERE p_id = ? AND cart_id = ?";
        $remove_stmt = $conn->prepare($remove_sql);
        $remove_stmt->execute([$product_id, $_SESSION["cart_id"]]);
    } else {
        $update_cart_sql = "UPDATE cart_items SET quantity = ? WHERE p_id = ? AND cart_id = ?";
        $update_cart_stmt = $conn->prepare($update_cart_sql);
        $update_cart_stmt->execute([$_SESSION["cart"][$product_id], $product_id, $_SESSION["cart_id"]]);
    }


    echo json_encode(["quantity" => $_SESSION["cart"][$product_id] ?? 0, "product_total" => $product_total ?? 0, "total" => $cart_total]);

?>