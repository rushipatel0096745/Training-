<?php 
    
    session_start();

    require_once __DIR__ . "../../../constants.php";
    require __DIR__ . '../../../database/db_connect.php';

    if(!isset($_SESSION["cart"])){
        $_SESSION["cart"] = [];   
    }
    else {
        $_SESSION["cart"] = [];

        // remove products from the cart_items for logges in user
        $remove_sql = "DELETE FROM cart_items WHERE cart_id = ?";
        $remove_stmt = $conn->prepare($remove_sql);
        $remove_stmt->execute([$_SESSION["cart_id"]]);
    }

?>