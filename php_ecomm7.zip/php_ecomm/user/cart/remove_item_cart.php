<?php 

    session_start();
    session_start();
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);

    require_once __DIR__ . "../../../constants.php";
    require __DIR__ . '../../../database/db_connect.php';
    
    $product_id = intval($_POST["product_id"]);

    if(!isset($_SESSION["cart"])){
        $_SESSION["cart"] = [];
    } else {
        unset($_SESSION["cart"][$product_id]);

        // remove from the cart_item table for logged in user
        $remove_sql = "DELETE FROM cart_items WHERE p_id = ? AND cart_id = ?";
        $remove_stmt = $conn->prepare($remove_sql);
        $remove_stmt->execute([$product_id, $_SESSION["cart_id"]]);

        echo "Product removed from cart";
    }


?>