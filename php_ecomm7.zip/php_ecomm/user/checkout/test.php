<?php
// PayU test endpoint
$url = "https://test.payu.in/_payment";

$key = "B8mbXl";
$salt = "ha18Zct9kuxwAa0n33blItch8fpdMs6l";

$txnid = 'txn_' . uniqid();
$hash = '';
// Hash Sequence1
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
$hashVarsSeq = explode('|', $hashSequence);
$hash_string = '';

echo floatval($_POST["amount"]) .  $_POST["productinfo"] . $_POST["firstname"] .  $_POST["email"] . $_POST["phone"];

function getHashKey($params)
{
    return hash('sha512', $params['key'] . '|' . $params['txnid'] . '|' . 50 . '|' . $params['productinfo'] . '|' . $params['firstname'] . '|' . $params['email'] . '|' . $params['udf1'] . '|' . $params['udf2'] . '|' . $params['udf3'] . '|' . $params['udf4'] . '|' . $params['udf5'] . '||||||' . $params['salt']);
}

$firstname = $_POST["firstname"];
$email = $_POST["email"];   
$phone = $_POST["phone"];
// $amount = $_POST["amount"];
$productinfo = $_POST["productinfo"];


$para = [
    'key'         => $key,
    'txnid'       => $txnid,
    'amount'      => 50,
    'productinfo' => $productinfo,
    'firstname'   => $firstname,
    'email'       => $email,
    'phone'       => $phone,
    'udf1'=>"",
    'udf2'=>"",
    'udf3'=>"",
    'udf4'=>"",
    'udf5'=>"",
    'salt' => $salt
];

// Order data
$postData = [
    // 'key'         => $key,
    // 'txnid'       => $txnid,
    // 'amount'      => $_POST["amount"],
    // 'firstname'   => $_POST["firstname"],
    // 'email'       => $_POST["email"],
    // 'phone'       => $_POST["phone"],
    'key'         => $key,
    'txnid'       => $txnid,
    'amount'      => 50,
    'productinfo' => $productinfo,
    'firstname'   => $firstname,
    'email'       => $email,
    'phone'       => $phone,
    'productinfo' => $_POST["productinfo"],
    'surl'        => 'http://localhost/rushikesh/php_ecomm/user/checkout/payment_success.php',
    'furl'        => 'http://localhost/rushikesh/php_ecomm/user/checkout/payment_failure.php',
    // compute the hash server-side using key|txnid|amount|productinfo|firstname|email|salt
    'hash'        =>  getHashKey($para)
];

// Initialize cURL
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// **Important: only send minimal headers**
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    // 'Content-Type: application/x-www-form-urlencoded'
]);

// Execute
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo 'cURL Error: ' . curl_error($ch);
} else {
    echo $response;
}

curl_close($ch);
