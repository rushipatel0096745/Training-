<?php
ini_set('session.cookie_lifetime', 86400);
ini_set('session.cookie_path', '/');
ini_set('session.cookie_secure', '0');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');

session_start();

ini_set("display_errors", "On");
error_reporting(E_ALL);

require __DIR__ . "/../../database/db_connect.php";
require "./PayU.php";
use APITestCode\PayU;

$payu = new PayU();
$payu->salt = "ha18Zct9kuxwAa0n33blItch8fpdMs6l";
$payu->key  = $_POST['key'] ?? '';

// Get payment details
$status        = $_POST["status"] ?? 'failed';
$firstname     = $_POST["firstname"] ?? '';
$amount        = $_POST["amount"] ?? '0';
$txnid         = $_POST["txnid"] ?? '';
$posted_hash   = $_POST["hash"] ?? '';
$key           = $_POST["key"] ?? '';
$productinfo   = $_POST["productinfo"] ?? '';
$email         = $_POST["email"] ?? '';
$error_message = $_POST["error_Message"] ?? $_POST["error"] ?? 'Payment failed';
$field         = $_POST["field"] ?? '';

$udf1 = $_POST['udf1'] ?? '';
$udf2 = $_POST['udf2'] ?? '';
$udf3 = $_POST['udf3'] ?? '';
$udf4 = $_POST['udf4'] ?? '';
$udf5 = $_POST['udf5'] ?? '';

// Verify hash for failure response (same as success)
$base = $payu->salt . '|' . $status;

if (!empty($_POST['additionalCharges'])) {
    $base .= '|' . $_POST['additionalCharges'];
}

$base .= '||||||' . $udf5 . '|' . $udf4 . '|' . $udf3 . '|' . $udf2 . '|' . $udf1 . '|' .
        $email . '|' . $firstname . '|' . $productinfo . '|' .
        $amount . '|' . $txnid . '|' . $key;

$calculatedHash = strtolower(hash('sha512', $base));

$order_id = $_SESSION['current_order_id'] ?? 0;


if ($order_id > 0 && !empty($txnid)) {
    $sql = "UPDATE orders 
            SET payment_status = 'FAILED',
                payment_txn_id = ?,
            WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$txnid, $order_id]);
}


$user_message = "We're sorry, but your payment could not be processed.";
$error_details = $error_message;

switch (strtolower($status)) {
    case 'bounced':
        $user_message = "Your payment was declined by your bank.";
        $error_details = "Please check your card details or try a different payment method.";
        break;
    case 'failed':
        $user_message = "Payment processing failed.";
        break;
    case 'usercancel':
    case 'cancelled':
        $user_message = "You cancelled the payment.";
        $error_details = "No charges were made to your account.";
        break;
    case 'timeout':
        $user_message = "Payment session timed out.";
        $error_details = "Please try again.";
        break;
}

// Save session before rendering
session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed</title>
</head>
<body>

<div class="container">

        <h1>Payment Failed</h1>
        <p class="subtitle"><?= htmlspecialchars($user_message) ?></p>

        <?php if (!empty($error_details)): ?>
        <div class="error-message">
            <strong>Error:</strong> <?= htmlspecialchars($error_details) ?>
        </div>
        <?php endif; ?>

        <div class="details-box">
            <?php if ($order_id > 0): ?>
            <div class="detail-row">
                <span class="detail-label">Order ID:</span>
                <span class="detail-value">#<?= htmlspecialchars($order_id) ?></span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($txnid)): ?>
            <div class="detail-row">
                <span class="detail-label">Transaction ID:</span>
                <span class="detail-value"><?= htmlspecialchars($txnid) ?></span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($amount) && $amount > 0): ?>
            <div class="detail-row">
                <span class="detail-label">Amount:</span>
                <span class="detail-value">₹<?= htmlspecialchars($amount) ?></span>
            </div>
            <?php endif; ?>
            
            <div class="detail-row">
                <span class="detail-label">Status:</span>
                <span class="detail-value" style="color: #e53e3e; font-weight: 600;">
                    <?= htmlspecialchars(strtoupper($status)) ?>
                </span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Date & Time:</span>
                <span class="detail-value"><?= date('d M Y, h:i A') ?></span>
            </div>
        </div>

        <div class="button-group">
            <a href="./checkout.php" class="btn btn-primary">Try Again</a>
            <a href="../cart.php" class="btn btn-secondary">View Cart</a>
        </div>
    </div>
    
</body>
</html>