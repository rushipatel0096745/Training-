// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()


// insert into oreders 
// $insert_orders_sql = "INSERT INTO orders (user_id, order_total) VALUES (?,?)";
// $insert_orders_stmt = $conn->prepare($insert_orders_sql);
// $insert_orders_stmt->execute([$login_user_id, $cart_total]);
// $last_order_id = $conn->lastInsertId();

// echo var_dump($products);
// foreach($products as $pr){
//     $insert_order_item_sql = "INSERT INTO order_items (order_id, p_id, quantity, unit_price) VALUES (?,?,?,?)";
//     $insert_order_item_stmt = $conn->prepare($insert_order_item_sql);
//     $insert_order_item_stmt->execute([$last_order_id, $pr["p_id"], $pr["quantity"], $pr["price"]]);
// }