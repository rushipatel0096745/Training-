<?php

    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    session_start();

    require '../../database/db_connect.php';


    // $login_user_id = $_SESSION["login_user_id"] ?? 0;
    // fetch cart items
    // $cart_items = $_SESSION["cart"] ?? [];

    if($_SESSION["login_user_id"]) {
        // return database cart data

        $user_id = $_SESSION["login_user_id"];

        $sql = "SELECT CI.p_id AS product_id, CI.quantity AS quantity 
                FROM cart C
                JOIN cart_items CI ON C.cart_id = CI.cart_id 
                WHERE C.user_id = ?
                ";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$user_id]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $cart_items = [];

        foreach($items as $i){
            $cart_items += [
                $i["product_id"] => $i["quantity"]
            ];
        }
        $cart_total = 0;
        if(empty($cart_items)){
            $products = [];
        } else {
            $all_product_ids = array_keys($cart_items);
            $placeholder = array_fill(0, count($all_product_ids), "?");
            $placeholder = implode(",", $placeholder);
        
            $product_sql = "SELECT * FROM product WHERE p_id IN ($placeholder)";
            $product_stmt = $conn->prepare($product_sql);
            $product_stmt->execute($all_product_ids);
            $products = $product_stmt->fetchAll(PDO::FETCH_ASSOC);
        
            foreach ($products as &$product) {
                $product["quantity"] = $cart_items[$product["p_id"]];
                $product["subtotal"] = $product["quantity"] * $product["price"];
                $cart_total += $product["subtotal"];
            }
            echo json_encode(["cart_total" => $cart_total, "products" => $products]);
        }
    } else {
            $cart_items = $_SESSION["cart"] ?? [];

            $cart_total = 0;

            if (empty($cart_items)) {
                $products = [];
            } else {
                $all_product_ids = array_keys($cart_items);
                $placeholder = array_fill(0, count($all_product_ids), "?");
                $placeholder = implode(",", $placeholder);
        
                $product_sql = "SELECT * FROM product WHERE p_id IN ($placeholder)";
                $product_stmt = $conn->prepare($product_sql);
                $product_stmt->execute($all_product_ids);
                $products = $product_stmt->fetchAll(PDO::FETCH_ASSOC);
        
                foreach ($products as &$product) {
                    $product["quantity"] = $cart_items[$product["p_id"]];
                    $product["subtotal"] = $product["quantity"] * $product["price"];
                    // if($product["p_id"] == $product_id){
                    //     $product_total = $product["subtotal"];
                    // }
                    $cart_total += $product["subtotal"];
                }    
            }
            echo json_encode(["cart_total" => $cart_total, "products" => $products]);
    }


    ?>










