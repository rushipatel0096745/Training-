<?php
session_start();
ini_set('display_errors', 'On');
error_reporting(E_ALL);

require_once __DIR__ . "/../constants.php";

if(!isset($_SESSION["login_user_id"])){
    header("Location: ./login.php");
    exit();
}


require '../database/db_connect.php';

$product_id = intval($_GET["p_id"]) ?? 0;

if($product_id !== 0) {
    $sql = "SELECT * FROM product WHERE p_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$product_id]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $product = [];
    foreach($result as $r){
        foreach($r as $k => $v){
            $product += [$k => $v];
        }
    }
    var_dump($product);
} else {
    echo "Product does not exist";
}

?>



<!doctype html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
</head>

<body>

    <div class="container-fluid m-0 p-0">
      
        <?php require '../user/components/user_navbar.php'; ?>



<div class="container py-5">
    <div class="row">

    <?php ?>
        <!-- Product Images -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <img src="<?php echo $product["image"] ?>" class="card-img-top" style="height: 450px;" alt="Product Image">
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-3">
                            <img src="https://images.unsplash.com/photo-1434056886845-dac89ffe9b56?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NzEyNjZ8MHwxfHNlYXJjaHwyfHx3YXRjaHxlbnwwfDB8fHwxNzM0OTY1MTc4fDA&ixlib=rb-4.0.3&q=80&w=1080" class="img-thumbnail" alt="Thumbnail 1">
                        </div>
                        <div class="col-3">
                            <img src="https://images.unsplash.com/photo-1495857000853-fe46c8aefc30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NzEyNjZ8MHwxfHNlYXJjaHw2fHx3YXRjaHxlbnwwfDB8fHwxNzM0OTY1MTc4fDA&ixlib=rb-4.0.3&q=80&w=1080" class="img-thumbnail" alt="Thumbnail 2">
                        </div>
                        <div class="col-3">
                            <img src="https://images.unsplash.com/photo-1451859757691-f318d641ab4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NzEyNjZ8MHwxfHNlYXJjaHw3fHx3YXRjaHxlbnwwfDB8fHwxNzM0OTY1MTc4fDA&ixlib=rb-4.0.3&q=80&w=1080" class="img-thumbnail" alt="Thumbnail 3">
                        </div>
                        <div class="col-3">
                            <img src="https://images.unsplash.com/photo-1490915785914-0af2806c22b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NzEyNjZ8MHwxfHNlYXJjaHwzfHx3YXRjaHxlbnwwfDB8fHwxNzM0OTY1MTc4fDA&ixlib=rb-4.0.3&q=80&w=1080" class="img-thumbnail" alt="Thumbnail 4">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Product Details -->
        <div class="col-md-6">
            <h1 class="h2 mb-3"><?php echo $product["product_name"] ?></h1>
            <div class="mb-3">
                <span class="h4 me-2"><?php echo $product["price"] ?></span>
                <span class="text-muted text-decoration-line-through"><?php echo $product["compare_price"] ?></span>
                <span class="badge bg-danger ms-2">25% OFF</span>
            </div>

            <div class="mb-3">
                <div class="d-flex align-items-center">
                    <div class="text-warning me-2">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                    <span class="text-muted">(128 reviews)</span>
                </div>
            </div>

            <p class="mb-4"><?php echo $product["description"] ?></p>

            <!-- Color Selection
            <div class="mb-4">
                <h6 class="mb-2">Color</h6>
                <div class="btn-group" role="group">
                    <input type="radio" class="btn-check" name="color" id="silver" checked>
                    <label class="btn btn-outline-secondary" for="silver">Silver</label>
                    <input type="radio" class="btn-check" name="color" id="gold">
                    <label class="btn btn-outline-secondary" for="gold">Gold</label>
                    <input type="radio" class="btn-check" name="color" id="black">
                    <label class="btn btn-outline-secondary" for="black">Black</label>
                </div>
            </div> -->

            <!-- Quantity -->
            <!-- <div class="mb-4">
                <div class="d-flex align-items-center">
                    <label class="me-2">Quantity:</label>
                    <select class="form-select w-auto">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                        </select>
                </div>
            </div> -->

            <!-- Actions -->
            <div class="d-grid gap-2">
                <button class="btn btn-primary" type="button">Add to Cart</button>
                <button class="btn btn-outline-secondary" type="button">
                        Buy now
                    </button>
            </div>

            <!-- Additional Info -->
            <div class="mt-4">
                <div class="d-flex align-items-center mb-2">
                    <i class="fas fa-truck text-primary me-2"></i>
                    <span>Free shipping on orders over $50</span>
                </div>
                <div class="d-flex align-items-center mb-2">
                    <i class="fas fa-undo text-primary me-2"></i>
                    <span>30-day return policy</span>
                </div>
                <div class="d-flex align-items-center">
                    <i class="fas fa-shield-alt text-primary me-2"></i>
                    <span>2-year warranty</span>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>

    <script>

        function addtoCart(event, product_id){
            event.preventDefault();

            const req = new XMLHttpRequest();
            const formData = new FormData();

            formData.append("product_id", product_id);

            console.log(product_id);

            req.open("POST", "./cart/add_to_cart.php");
            req.send(formData);   

            req.addEventListener('load', function(){
                // const res = JSON.parse(this.responseText);
                // alert("res");
                console.log(this.responseText);
                alert(this.responseText);
            })
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>