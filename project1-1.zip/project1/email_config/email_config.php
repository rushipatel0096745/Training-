<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require './vendor/autoload.php';


function initializeMailer() {
    $mail = new PHPMailer(true); // Passing 'true' enables exceptions

    try {
        // Server settings
        $mail->SMTPDebug = 0;                                       
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com;';                    
        $mail->SMTPAuth   = true;                             
        $mail->Username   = 'rp0096745@gmail.com';                 
        $mail->Password   = 'gjmndkiyygxmlvwv';                        
        $mail->SMTPSecure = 'tls';                              
        $mail->Port       = 587;  

        // Sender settings
        $mail->setFrom('rp0096745@gmail.com', 'rushi patel');    
        
        return $mail;

    } catch (Exception $e) {
        error_log("Mailer Initialization Error: " . $e->getMessage());
        return null;
    }
}

?>