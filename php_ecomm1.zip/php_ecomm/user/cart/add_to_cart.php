<?php 

    session_start();
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);

    if(isset($_POST["product_id"])){
        $product_id = (int)$_POST["product_id"];
    }


    // echo "product_id" . " " . $product_id;

    if(!isset($_SESSION["cart"])){
        $_SESSION["cart"] = [
            $product_id => 1
        ];
    } else {
        if(in_array($product_id, array_keys($_SESSION["cart"]))){
            $_SESSION["cart"][$product_id] += 1;
        } else {
            $_SESSION["cart"] += [
                $product_id => 1
            ];
        }
    }

    // unset($_SESSION["cart"]);

    echo "product added to cart";

?>