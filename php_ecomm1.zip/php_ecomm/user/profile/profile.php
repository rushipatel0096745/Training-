<?php


// fetching current loggen in user



?>

<!doctype html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body>
    <div class="container d-flex align-items-center justify-content-center vh-100">

        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="" novalidate>
            <div class="row mb-3 text-center">
                <h1>Profile</h1>
            </div>
            <div class="row mb-3">
                <label for="first_name" class="col-sm-3 col-form-label">First name: </label>
                <div class="col-sm-9">
                    <input type="text" name="first_name" class="form-control req" id="inputEmail3" required disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$fnameErr"; ?></span>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="last_name" class="col-sm-3 col-form-label">Last name: </label>
                <div class="col-sm-9">
                    <input type="text" name="last_name" class="form-control req" id="inputEmail3" required disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$lnameErr"; ?></span>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="email" class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-9">
                    <input type="email" name="email" class="form-control req" id="inputEmail3" disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$emailErr"; ?></span>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <label for="mob" class="col-sm-3 col-form-label">Phone no. </label>
                <div class="col-sm-9">
                    <input type="tel" name="mob" class="form-control req" id="inputEmail3" disabled>
                    <div id="">
                        <span class="bs-danger"><?php echo "$mobErr"; ?></span>
                    </div>
                </div>
            </div>

            <div id="">
                <span class="bs-danger"><?php echo "$signUpErr"; ?></span>
            </div>
            <div class="row mb-3 justify-content-center text-center">
                <div>
                    <button type="submit" class="btn btn-primary mx-2">Submit</button>
                    <button class="btn btn-primary mx-2 edit">Edit</button>
                    <button type="button" class="btn btn-primary change-pass">
                        Change Password
                    </button>
                </div>
            </div>
        </form>

    </div>

    <script>
        let editBtn = document.querySelector(".edit");
        let allFields = document.querySelectorAll(".req");
        let showBtn = document.querySelector(".show1");
        let pass = document.querySelector(".pass");


        editBtn.addEventListener("click", function(event) {
            event.preventDefault();
            allFields.forEach((field) => {
                if (field.hasAttribute('disabled')) {
                    field.removeAttribute('disabled')
                } else {
                    field.disabled = true
                }
            })
        })

        document.querySelector(".change-pass").addEventListener("click", function() {
            window.location.href = "change_password.php";
        });
    </script>

    <script src="validation.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>