<?php 
    session_start();
    if(!isset($_SESSION["reset_id"])){
        header("Location: forget_password.php");
        exit();
    }
?>

<?php 
    define("BASE_PATH", "../../");
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
    require BASE_PATH . 'database/db_connect.php';

    $new_password = $confirm_password = $errMsg = "";

    $reset_admin_id = $_SESSION["reset_admin_id"];
    $reset_id = $_SESSION["reset_id"];

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["new_password"])){
            $errMsg = "Enter the password";
        } else {
            $new_password = $_POST["new_password"];
        }
        if(empty($_POST["confirm_password"])){
            $errMsg = "Enter the password";
        } else {
            $confirm_password = $_POST["confirm_password"];
        }


        if($new_password == $confirm_password){
            // update the password
            $pass_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $update_sql = "UPDATE admin SET password_hash = ? WHERE admin_id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->execute([$pass_hash, $reset_admin_id]);

            // delete the otp from the password_reset_table
            $delete_sql = "DELETE FROM password_reset WHERE id = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->execute([$reset_id]);

            // unset the session variables
            unset($_SESSION["reset_email"]);
            unset($_SESSION["reset_admin_id"]);
            unset($_SESSION["reset_id"]);

            // redirect to login page
            header("Location: " . BASE_PATH . "admin/login.php");
            exit();
        } else {
            $errMsg = "Passwords are not matching";
        }


    }


?>

<!doctype html>
<html lang="en" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Password Reset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="container d-flex align-items-center justify-content-center vh-100"> 
                <div class="card">
                    <div class="card-header">
                        Reset Password
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>" onsubmit="">
                            <label for="new_password">New Password</label>
                            <input type="password" name="new_password" class="form-control otp">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control otp">
                            <div class="text-danger"><?php echo $errMsg; ?></div>
                            <input type="submit" class="btn btn-primary mt-3"></input>
                        </form>
                    </div>
                </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>