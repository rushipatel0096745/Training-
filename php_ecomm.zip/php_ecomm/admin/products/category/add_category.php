<?php 
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);

    session_start();
    if(!isset($_SESSION["admin"])){
        header("Location: ../login.php");
        exit();
    }

    require "../../../constants.php";
    require '../../../database/db_connect.php';
    
    // fetch all the categories
    try {
        $cat_sql = "SELECT * FROM category order by c_id";
        $cat_stmt = $conn->prepare($cat_sql);
        $cat_stmt->execute();
        $categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "error: " . $e->getMessage();
    }

    $errMsg = "";
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(empty($_POST["category"])){
            $errMsg = "enter the category name";
        } else {
            $category_name = $_POST["category"];
        }
        
        if($errMsg == ""){
            try {
                // inserting category
                $last_cat_id = 0;
                foreach($categories as $c){
                    $last_cat_id = $c["c_id"];
                }
                $insert_sql = "INSERT INTO category (c_id, category_name) VALUES (?,?)";
                $insert_stmt = $conn->prepare($insert_sql);
                $insert_stmt->execute([$last_cat_id+1, $category_name]);
                
                $_SESSION["success"] = "Category added successfully";
                header("Location: add_category.php");
                exit();
            } catch (PDOException $e) {
                echo "error: " . $e->getMessage();
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Categories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>    
    <div class="container-fluid p-0 m-0">

        <?php include '../../../components/navbar.php' ?>

        <div class="container mt-5 mx-auto">

            <!-- add category modal  -->
            <div class="modal modal-sm fade" id="addCategory" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="card">
                                <div class="card-header">
                                    Add Category
                                </div>
                                <div class="card-body">
                                    <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>" onsubmit="return submitHandler(event)">
                                        <label for="category">Category name</label>
                                        <input type="text" name="category" class="form-control category">
                                        <div class="text-danger"><?php echo $errMsg; ?></div>
                                        <input type="submit" class="btn btn-primary mt-3" value="Add Category">
                                    </form>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Success message -->
            <?php if(isset($_SESSION["success"])){ ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION["success"]; unset($_SESSION["success"]); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php } ?>

            <div class="row justify-content-between mb-3">
                <div class="col-md-6">
                    <h4>Categories</h4>
                </div>
                <div class="col-md-6 text-end">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategory">Add Category</button>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Category ID</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($categories as $c){ ?>
                                <tr>
                                    <td><?php echo $c["c_id"] ?></td>
                                    <td><?php echo $c["category_name"] ?></td>
                                    <td>
                                        <a href="delete_category.php?c_id=<?php echo $c["c_id"] ?>" 
                                           class="btn btn-outline-danger btn-sm"
                                           onclick="return confirm('Are you sure you want to delete this category?')">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>  
    </div>

    <script>
        function submitHandler(event){
            const category = document.querySelector(".category");
            if(category.value.trim() == ""){
                category.nextElementSibling.textContent = "Enter the category";
                event.preventDefault();
                return false;
            }
            return true;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>