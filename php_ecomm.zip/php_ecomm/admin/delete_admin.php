<?php
session_start();
if (!isset($_SESSION["admin"])) {
  header("Location: login.php");
  exit();
}
?>

<?php
session_start();
include './database/db_connect.php';
$admin_id = $_GET["id"];

$current_admin_id = $_SESSION["admin"];
$target_admin_id = $admin_id;

if ($current_admin_id != 1) {
  $_SESSION["error"] = "You don't have permission to delete admins";
  header("Location: dashboard.php");
  exit();
}

if ($target_admin_id == 1) {
  $_SESSION["error"] = "Cannot delete the main admin account";
  header("Location: dashboard.php");
  exit();
}
try {
  $sql = "DELETE FROM admin WHERE admin_id = :admin_id";
  $stmt = $conn->prepare($sql);
  $stmt->bindParam(":admin_id", $admin_id);
  $stmt->execute();

} catch (PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

header("Location: dashboard.php");
exit();

?>