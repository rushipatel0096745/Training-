<?php
$servername = "localhost";
$username = "root";
$password = "admin";
$dbname = "ecommerce";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // $sql = "insert into admin (email, password_hash, role_id, name) values (?,?,?,?)";
  // $stmt= $conn->prepare($sql);
  // $stmt->execute(['john@gmail.com', password_hash('123456', PASSWORD_DEFAULT), 2, 'John Doe']);



  echo "Connected successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}

?>